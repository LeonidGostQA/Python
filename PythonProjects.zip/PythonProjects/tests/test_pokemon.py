import requests
import pytest

URL = 'https://api.pokemonbattle.me/v2'
HEADERS = {'Content-Type' : 'application/json', 'trainer_token' : 'b9401e10a810318cc7bb47db5c9abc48'}

def test_status_code():
    response = requests.get(url = f'{URL}/trainers', params = {"trainer_id" : 805})
    assert response.status_code == 200
   
