import requests

URL = 'https://api.pokemonbattle.me/v2'
HEADERS = {'Content-Type' : 'application/json', 'trainer_token' : 'b9401e10a810318cc7bb47db5c9abc48'}

body = {
    "pokemon_id": "14030"
}

response = requests.post(url = f'{URL}/trainers/add_pokeball', headers = HEADERS, json = body)

print(response.text)