import requests

URL = 'https://api.pokemonbattle.me/v2'
HEADERS = {'Content-Type' : 'application/json', 'trainer_token' : 'b9401e10a810318cc7bb47db5c9abc48'}

body = {
    "name": "BatMan",
    "photo": "https://dolnikov.ru/pokemons/albums/045.png"
}

response = requests.post(url = f'{URL}/pokemons', headers = HEADERS, json = body)

print(response.text)